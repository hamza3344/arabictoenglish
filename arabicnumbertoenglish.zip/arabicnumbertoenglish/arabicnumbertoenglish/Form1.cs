﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace arabicnumbertoenglish
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string[] arabic = { "٠", "١", "٢", "٣", "٤", "٥", "٦", "٧", "٨", "٩" };
            string[] english = { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" };
            string result = textBox1.Text;
            int i = 0;
            foreach(string s in arabic)
            {
                result = result.Replace(english[i], arabic[i]);
                i = i + 1;
            }
            MessageBox.Show(result + "\n" + new string(result.ToCharArray().Reverse().ToArray()));
        }
    }
}
